#!/bin/bash


/bin/bash /home/jack/release/rsync_php_theone.sh
/bin/bash /home/jack/release/rsync_web_h5.sh
/bin/bash /home/jack/release/rsync_admin_h5.sh



